
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user</title>
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>

    
<div class="container">
    <h1>Add New user</h1>

    <form action="empinsert" method="POST" class="card-body" enctype="multipart/form-data">

        <label for="" >name:</label><br>
        <input type="text" id="" name="nm" class="form-control" required><br><br> 
        
        <label for="">address:</label><br>
        <input type="text" id="" name="add" class="form-control" required><br><br> 

        <label for="">designation:</label><br>
        <input type="text" id="" name="des" class="form-control" required><br><br> 

        <label for="">salary:</label><br>
        <input type="text" id="" name="sal" class="form-control"  required><br><br> 
        
        <label for="">picture:</label><br>
        <input type="file" id="" name="pic" class="form-control"  required><br><br>

        <input type="submit" class="btn btn-success">
        <input type="reset" class="btn btn-danger">

    </form>
</div>

</body>
</html>