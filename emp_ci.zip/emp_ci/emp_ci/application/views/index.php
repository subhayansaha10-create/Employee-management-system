<!DOCTYPE html>
<html>
<head>
    <title>Employee List</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4 text-center">Employee List</h2>
    
    <a href="<?php echo base_url('empaddform'); ?>" class="btn btn-sm btn-warning">Add Employee</a>

    <a href="<?php echo base_url('login'); ?>" class="btn btn-sm btn-info">Login</a><br>

    <?php if (!empty($employees)) { ?>
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Address</th>
                    <th>Designation</th>
                    <th>Salary</th>
                    <th>Picture</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($employees as $emp) { ?>

                    <tr>
                        <td><?= $emp['id']; ?></td>
                        <td><?= $emp['name']; ?></td>
                        <td><?= $emp['address']; ?></td>
                        <td><?= $emp['designation']; ?></td>
                        <td><?= $emp['salary']; ?></td>
                        <td><img src="<?php echo base_url("uploads/".$emp['picture'] )?>" style="height:50px;width:50px" alt=""></td>
                        <td>
                            
                            <a href="<?php echo base_url('empeditform/'.$emp['id']); ?>" class="btn btn-sm btn-warning">Edit</a>

                            <a href="<?php echo base_url('empdelete/'.$emp['id']); ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this employee?')">Delete</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <div class="alert alert-info text-center">
            No employees found.
        </div>
    <?php } ?>
</div>

</body>
</html>
