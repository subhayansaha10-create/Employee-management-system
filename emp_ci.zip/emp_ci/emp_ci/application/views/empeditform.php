<!DOCTYPE html>
<html>
<head>
    <title>emp</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
    <div class="card">

       <div class="card-header">
        <h2>Edit emp</h2>
       </div>
       <div class="card-body">
        <form method="post" action="<?php echo base_url('empupdate/'.$emp['id']);?>"  enctype="multipart/form-data" >

            <p>Name : <input class="form-control" type="text" name="nm" value="<?php echo $emp['name'] ?>"></p>

            <p>address : <input class="form-control" type="text" name="add" value="<?php echo $emp['address'] ?>"></p>

            <p>Designation : <input class="form-control" type="text" name="des" value="<?php echo $emp['designation'] ?>"></p>

            <p>salary : <input class="form-control" type="number" name="sal" value="<?php echo $emp['salary'] ?>"></p>

            <p>picture :<img src="<?php echo base_url('uploads/'.$emp['picture']);?>" height="150px"  width="150px"></p>

            <input class="form-control" type="hidden" name="oldpic" value="<?php echo $emp['picture'] ?>">


            <p> Update picture : <input class="form-control" type="file" name="pic"></p>

            <button type="submit" class="btn btn-success" >update</button>
        </form>

    </div>
    </div>

</body>
</html>
