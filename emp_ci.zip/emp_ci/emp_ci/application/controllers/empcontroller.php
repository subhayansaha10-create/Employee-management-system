<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class empcontroller extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('empmodel');
        $this->load->helper(array('form','url'));
        $this->load->library('upload');
        $this->load->library('session');
        
    }

    public function index()
    {
        $data['employees'] = $this->empmodel->employees();
        $this->load->view('index', $data);
    }

    public function empaddform(){

        $this->load->view('empaddform');
    }
    
    public function empinsert()
    {

          if($this->input->post()){
            $config['upload_path']   = './uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size']      = 100000;

            $this->upload->initialize($config);
            
            if ($this->upload->do_upload('pic')) {

                $imageupload = $this->upload->data();
                $imagenames=$imageupload['file_name'];
                     
            }else{

                echo $this->upload->display_errors();
                return;
            }

            $data=[

                'name'=>$this->input->post('nm'),
                'address'=>$this->input->post('add'),
                'designation'=>$this->input->post('des'),
                'salary'=>$this->input->post('sal'),
                'picture'=>$imagenames
            ];

            $this->empmodel->empinsert($data);
            redirect('index');
        }
    }

    public function empeditform($id){
       $data['emp']=$this->empmodel->getemp($id);
       $this->load->view('empeditform',$data);
    }

    public function empupdate($id){

            $config['upload_path'] = './uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png|gif';
            $config['max_size'] = 2000000;

            $this->upload->initialize($config);
            $picture = $_FILES['pic']['name'];

            // echo '<pre>'; print_r($_FILES); die;

            if(!empty($picture)){
                if ($this->upload->do_upload('pic')) {

                 // if ($picture && file_exists('./uploads/'. $picture)) {
                 //     unlink('./uploads/'. $picture);
                 // }
                    $upload_data = $this->upload->data();
                    $picture= $upload_data['file_name'];
                }

            }else{
                // echo 'ok'; die;
                $picture = $this->input->post('oldpicture');
            }
           
        $data = [
            'name'=>$this->input->post('nm'),
            'address'=>$this->input->post('add'),
            'designation'=>$this->input->post('des'),
            'salary'=>$this->input->post('sal'),
            'picture'=>$picture
        ];

        $this->empmodel->empupdate($id, $data);
        redirect('index');
    }


    public function empdelete($id){
        $this->empmodel->deleteemp($id);
        redirect('index');
    }







    ///login

    public function login(){
       $this->load->view('login');
    }

    public function logincheck(){
       $email=$this->input->post('email');
       $password=$this->input->post('password');

       $user=$this->empmodel->get($email,$password);

        // echo '<pre>'; print_r($user); die;
        if($user){
            
           if($user['user_name']==$email && $user['password']==$password){
           echo 'login successful';
           }
        }else{
            echo 'wrong credintials';
        }
    }

}

