<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class empmodel extends CI_Model {


   public function empinsert($data)
    {
      return $this->db->insert('emp_details',$data);
    }


    public function employees()
    {
      return $this->db->get('emp_details')->result_array(); 
    }

    public function getemp($id){

      $this->db->where('id',$id);
      return $this->db->get('emp_details')->row_array();
    }


    public function empupdate($id,$data){

      $this->db->where('id',$id);
      return $this->db->update('emp_details',$data);

    }


    public function deleteemp($id){

      $this->db->where('id',$id); 
      return $this->db->delete('emp_details');   
    }





   ////login 

   public function get($email,$password){

      $this->db->where('user_name',$email);
      $this->db->where('password',$password);
      $user=$this->db->get('login_details');
  
      if($user->num_rows()==1){
        return $user->row_array();
      }else{
        return false;
      }

   }








}
